package com.cts.product.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.product.bean.Category;
import com.cts.product.bean.Product;
import com.cts.product.bean.ProductVendor;
import com.cts.product.bean.Vendors;
import com.cts.product.service.CategoryService;
import com.cts.product.service.ProductService;
import com.cts.product.service.ProductVendorService;
import com.cts.product.service.VendorService;

@Controller
public class VendorController {

	@Autowired
	CategoryService categoryService;
	
	@Autowired
	VendorService vendorService;
	
	@Autowired
	ProductVendorService productVendorService;
	
	
	@Autowired
	//@Qualifier("productService")
	ProductService productService;
	
	
	/*@RequestMapping(value="Vendor-ListProduct.html")
	public ModelAndView getListProduct(HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
		List<Vendors> vendors = vendorService.getAllVendors();
		
		modelAndView.addObject("products", vendors);
		modelAndView.setViewName("Admin-ListProducts");
		return modelAndView;
	}*/
	
	
	
	
	@RequestMapping("Vendor-AddProduct2.html")
	public String getVendorAddProduct(){
		return "Vendor-AddProduct2";
	}
	/*
	@RequestMapping("Admin-ListProducts.html")
	public String getAddProduct(){
		return "Admin-ListProducts";
	}*/
	

	
	@RequestMapping("Vendor-AddProduct12.html")
	public ModelAndView displayCategory(@ModelAttribute ProductVendor productVendor){
		
		ModelAndView modelAndView = new ModelAndView();
		List<Category> category = categoryService.getCategoryName();
		System.out.println(category);
		modelAndView.addObject("category", category);
		modelAndView.setViewName("Vendor-AddProduct2");
		return modelAndView;
		
	}
	
	@RequestMapping(value="Vendor-AddProduct2.html",method = RequestMethod.POST)
	public String addProduct(@ModelAttribute ProductVendor productVendor,HttpSession httpSession){
		//session
		
		ModelAndView modelAndView = new ModelAndView();
		
		
		if("true".equals(productVendorService.insertProductVendor(productVendor)))
		{
			System.out.println(productVendor);
			
			return "redirect:/Vendor-ListProduct.html";
		}
		else
		{
			return null;
		}
		
	}
	
	@RequestMapping(value="Vendor-ListProduct.html")
	public ModelAndView getListProduct(HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
		List<ProductVendor> products = productVendorService.getAllProductVendor(); 
		
		modelAndView.addObject("vendorProducts", products);
		modelAndView.setViewName("Vendor-ListProduct");
		return modelAndView;
	}
	
	@RequestMapping(value="sortingHighToLowV")
	public ModelAndView getDescendingProduct(HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
		List<ProductVendor> products = productVendorService.getDescProductVendor();
		
		modelAndView.addObject("vendorProducts", products);
		modelAndView.setViewName("Vendor-ListProduct");
		return modelAndView;
	}
	
	@RequestMapping(value="sortingLowToHighV")
	public ModelAndView getAscendingProduct(HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		List<Product> products = productService.getAllProduct();
		
		modelAndView.addObject("products", products);
		List<ProductVendor> productsVendor = productVendorService.getAscProductVendor();
		
		modelAndView.addObject("vendorProducts", productsVendor);
		modelAndView.setViewName("Vendor-ListProduct");
		return modelAndView;
	}
	
}
