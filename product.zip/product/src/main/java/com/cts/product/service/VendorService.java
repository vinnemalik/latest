package com.cts.product.service;

import java.util.List;

import com.cts.product.bean.Vendors;

public interface VendorService {

	public String insertVendor(Vendors vendors);
	public List<Vendors> getAllVendors();
}
